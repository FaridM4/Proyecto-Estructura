using Domain;
using Microsoft.EntityFrameworkCore;
using PruebaBlazor.Data;
using PruebaBlazor.Models; // Se a�ade el using para el nuevo modelo

namespace PruebaBlazor.Services
{
    public interface ICarritoService
    {
        // Se actualiza para que devuelva el modelo con detalles del libro
        Task<List<CarritoItemModel>> GetCarritoAsync(int usuarioId);
        Task AddToCarritoAsync(int usuarioId, int libroId, int cantidad);
        Task RemoveFromCarritoAsync(int carritoItemId);
        Task ClearCarritoAsync(int usuarioId);
        // Nuevo m�todo para calcular el total
        Task<decimal> GetTotalCarritoAsync(int usuarioId);
    }

    public class CarritoService : ICarritoService
    {
        private readonly LibreriaDbContext _context;
        public CarritoService(LibreriaDbContext context) => _context = context;

        // Implementaci�n actualizada de GetCarritoAsync
        public async Task<List<CarritoItemModel>> GetCarritoAsync(int usuarioId)
        {
            // Se usa Include() para cargar los datos del libro relacionado y Select() para proyectar al nuevo modelo.
            // Esto es mucho m�s eficiente que hacer consultas separadas.
            return await _context.CarritoItems
                .Where(c => c.UsuarioId == usuarioId)
                .Include(c => c.Libro) // Esto funciona gracias a la propiedad de navegaci�n
                .Select(c => new CarritoItemModel
                {
                    CarritoItemId = c.Id,
                    LibroId = c.LibroId,
                    Titulo = c.Libro.Titulo,
                    Precio = c.Libro.Precio,
                    ImagenUrl = c.Libro.ImagenUrl,
                    Cantidad = c.Cantidad
                }).ToListAsync();
        }

        public async Task AddToCarritoAsync(int usuarioId, int libroId, int cantidad)
        {
            var item = await _context.CarritoItems.FirstOrDefaultAsync(c => c.UsuarioId == usuarioId && c.LibroId == libroId);
            if (item != null)
            {
                item.Cantidad += cantidad;
            }
            else
            {
                _context.CarritoItems.Add(new CarritoItem { UsuarioId = usuarioId, LibroId = libroId, Cantidad = cantidad });
            }
            await _context.SaveChangesAsync();
        }

        public async Task RemoveFromCarritoAsync(int carritoItemId)
        {
            var item = await _context.CarritoItems.FindAsync(carritoItemId);
            if (item != null)
            {
                _context.CarritoItems.Remove(item);
                await _context.SaveChangesAsync();
            }
        }

        public async Task ClearCarritoAsync(int usuarioId)
        {
            var items = _context.CarritoItems.Where(c => c.UsuarioId == usuarioId);
            _context.CarritoItems.RemoveRange(items);
            await _context.SaveChangesAsync();
        }

        // Nueva implementaci�n para calcular el total del carrito
        public async Task<decimal> GetTotalCarritoAsync(int usuarioId)
        {
            // Se usa SumAsync para calcular el total directamente en la base de datos
            return await _context.CarritoItems
                .Where(c => c.UsuarioId == usuarioId)
                .Include(c => c.Libro)
                .SumAsync(c => c.Libro.Precio * c.Cantidad);
        }
    }
}
