using Domain;
using Microsoft.EntityFrameworkCore;
using PruebaBlazor.Data;

namespace PruebaBlazor.Services
{
public interface IOrdenService
    {  
        Task<List<Orden>> GetOrdenesAsync(int usuarioId);
        Task<Orden?> GetOrdenAsync(int id);
        Task<int> CrearOrdenAsync(int usuarioId, decimal total);
    }

    public class OrdenService : IOrdenService
    {
        private readonly LibreriaDbContext _context;
        public OrdenService(LibreriaDbContext context) => _context = context;

        public async Task<List<Orden>> GetOrdenesAsync(int usuarioId) =>
            await _context.Ordenes.Where(o => o.UsuarioId == usuarioId).ToListAsync();

        public async Task<Orden?> GetOrdenAsync(int id) => await _context.Ordenes.FindAsync(id);

        public async Task<int> CrearOrdenAsync(int usuarioId, decimal total)
        {
            var orden = new Orden { UsuarioId = usuarioId, Fecha = DateTime.Now, Total = total };
            _context.Ordenes.Add(orden);
            await _context.SaveChangesAsync();
            return orden.Id;
        }
    }
}
