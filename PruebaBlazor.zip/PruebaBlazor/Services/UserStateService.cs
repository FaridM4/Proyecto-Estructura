using Domain;
using PruebaBlazor.Models;

namespace PruebaBlazor.Services
{
    public class UserStateService
    {
        public Usuario? CurrentUser { get; private set; }

        public bool IsLoggedIn => CurrentUser != null;

        public void SetCurrentUser(Usuario? user)
        {
            CurrentUser = user;
            NotifyStateChanged();
        }

        public event Action? OnChange;

        private void NotifyStateChanged() => OnChange?.Invoke();
    }

    // Este modelo combina los datos del CarritoItem y del Libro
    public class CarritoItemModel
    {
        public int CarritoItemId { get; set; }
        public int LibroId { get; set; }
        public string Titulo { get; set; } = string.Empty;
        public decimal Precio { get; set; }
        public string ImagenUrl { get; set; } = string.Empty;
        public int Cantidad { get; set; }
        public decimal Subtotal => Precio * Cantidad;
    }
}
