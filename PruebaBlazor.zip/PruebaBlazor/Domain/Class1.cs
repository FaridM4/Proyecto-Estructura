﻿namespace PruebaDomain
{
    // Las entidades han sido movidas a archivos separados.
}
